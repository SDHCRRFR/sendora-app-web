import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import TermsView from '../views/TermsView.vue'
import CGUView from '../views/CGUView.vue'
import PrivacyView from '@/views/PrivacyView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', component: HomeView, meta: { title: 'Sendora – Envoyez et transportez malin' } },
    { path: '/terms', component: TermsView, meta: { title: "Conditions d'utilisation – Sendora" } },
    {
      path: '/privacy',
      component: PrivacyView,
      meta: { title: 'Politique de confidentialité – Sendora' },
    },
    { path: '/cgu', component: CGUView, meta: { title: 'CGU – Sendora' } },
  ],
})

export default router
