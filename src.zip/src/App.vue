<template>
  <div id="sendora-app">
    <!-- <NavBar /> -->
    <router-view v-slot="{ Component }">
      <transition name="page" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
    <!-- <FooterBar /> -->
  </div>
</template>

<script lang="ts" setup>
// import NavBar from './components/NavBar.vue'
// import FooterBar from './components/FooterBar.vue'
</script>

<style>
#sendora-app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
</style>