<template>
  <h1>Legallayout</h1>
</template>

<!-- <script lang="ts" setup>

</script> -->

<style scoped>

</style>